<sfback>
actions: <a href="{{URL::route('delegate-event-get',$event->id)}}">view</a>
 | 
 <a  href="{{URL::route('delegate-event-attend',$event->id)}}">attend</a>
</sfback>