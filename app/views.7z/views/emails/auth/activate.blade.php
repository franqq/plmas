<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2>Welcome to Plmas</h2>

		<div>
			Hello,<br /><br />
			
			Welcome to Plmas, please click on this <a href="{{$link}}">link</a> to confirm your membership.<br />

			If you are having any  trouble clicking on the link? Please copy and paste the following link in a new browser window: <br />
			
			-----<br /><br />
			
			{{$link}}
			
			------<br /><br />
			
			Regards.
		</div>
	</body>
</html>