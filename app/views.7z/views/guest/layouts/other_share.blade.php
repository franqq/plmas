<sfback>
share via: <a href="{{URL::route('facebook-squeeb',$event->id)}}" target="_blank" >facebook</a>
 | 
 <a  href="{{URL::route('tweet-squeeb',$event->id)}}" target="_blank" >twitter</a>
</sfback>