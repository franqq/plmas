<sfback>
share via: <a href="" target="_blank" >facebook</a>
 | 
 <a  href="" target="_blank" >twitter</a>
</sfback>