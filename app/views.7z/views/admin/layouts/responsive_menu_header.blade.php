<body id="page1" onLoad="new ElementMaxHeight();">
<div class="tail-bottom">
	<div id="main" class="zerogrid">
<!-- header -->
		<header>
			<div class="nav-box">
				<nav>
					<ul class="fright">
						<li><a href="{{URL::route('admin')}}">{{HTML::image('images/home.png','home')}}</a></li>
						<li><a href="{{URL::route('logout')}}">{{HTML::image('images/logout.png','logout')}}</a></li>
					</ul>