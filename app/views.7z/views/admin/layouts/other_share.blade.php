<sfback>
share via: <a href="{{URL::route('facebook-squeeb',$squeeb->squeebs_id)}}" target="_blank" >facebook</a>
 | 
 <a  href="{{URL::route('tweet-squeeb',$squeeb->squeebs_id)}}" target="_blank" >twitter</a>
</sfback>