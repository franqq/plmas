<div>
{{HTML::image('logos/default.png' , 'Jomo Kenyatta University of Agriculture and Technology',array('class' => 'institutionlogo'))}}
Jomo Kenyatta University of Agriculture and Technology
<p class="change-college"><a href="">
</a></p>
</div>
<div>
<p><h2 style="text-transform:capitalize;" ><span>@JKUAT</span></h2></p>
<div>