<sfback>
manage: <a href="{{URL::route('organiser-event-get',$event->id)}}">view</a>
 | 
 <a  href="{{URL::route('organiser-edit-get',$event->id)}}">edit</a>
</sfback>