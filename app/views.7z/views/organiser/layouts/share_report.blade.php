<br /><br />
<squeebshare>	
share via:
<a href="{{URL::route('facebook-squeeb',$squeeb->id)}}" target="_blank" >facebook</a>
 | 
<a href="{{URL::route('tweet-squeeb',$squeeb->id)}}" target="_blank" >twitter</a>
 | 
<a id="report" href="{{URL::route('report-squeeb',$squeeb->id)}}">report</a>
</squeebshare>