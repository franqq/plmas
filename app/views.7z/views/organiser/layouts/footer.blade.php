<!-- footer -->
		<footer>
		</footer>
	</div>
</div>
</body>
{{HTML::style('eventscallendar/css/paragridma.css')}}

<!-- Core CSS File. The CSS code needed to make eventCalendar works -->
{{HTML::style('eventscallendar/css/eventCalendar.css')}}

<!-- Theme CSS file: it makes eventCalendar nicer -->
{{HTML::style('eventscallendar/css/eventCalendar_theme_responsive.css')}}

<!--<script src="js/jquery.js" type="text/javascript"></script>-->
{{HTML::script('https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js')}}

{{HTML::script('eventscallendar/js/jquery.eventCalendar.js')}}

</html>