					<form method="get" action="/search" id="search">
						  <input name="qq" type="text" size="40" placeholder="Search..." />
					</form>
				